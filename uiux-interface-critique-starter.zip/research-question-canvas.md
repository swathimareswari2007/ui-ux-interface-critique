# Interface Critique & Research Question Canvas

## Project
**Title:** Making DigiLocker account access and document retrieval easier to understand  
**Workflow type:** Public-service / digital document access  
**Website:** https://www.digilocker.gov.in/

## Problem statement
People using a digital document service need to understand how to start, verify their account, find documents, and get help when a step is unclear. The critique will investigate whether public-facing guidance makes the next step, identity requirements, and available help easy to understand. This is a problem to investigate, not a claim that the service is defective.

## Primary research question
How do first-time and returning users understand the steps for accessing and retrieving documents through DigiLocker, and where do they need clearer guidance or reassurance?

## Three assumptions to validate
1. First-time users may be uncertain which sign-in or registration route applies to them.
2. Users may want clearer explanations of what happens after selecting “Continue” and what information they will need next.
3. Users may have difficulty finding help when they cannot proceed or do not understand document availability.

## Research plan
- Review the current public homepage and public account-access/help pages.
- Observe 3–5 willing participants navigating the public information pages; do not ask them to disclose identity details or log in for the study.
- Ask participants to think aloud and note where they hesitate, what they expect, and whether they can identify the next step.
- Record the date, exact page/state, evidence, impact, and confidence for each observation.
- Keep assumptions separate from confirmed findings.

## Heuristic review checklist
- **Clarity:** Are labels, instructions, and choices understandable?
- **Feedback:** Does the interface explain what happens after an action?
- **Error prevention:** Are input requirements and recovery options explained before users make errors?
- **Accessibility:** Are text, contrast, keyboard navigation, and accessible labels usable?
- **Trust:** Are official ownership, privacy expectations, and safe next steps clear?

## Success criteria
- Participants can explain the available access routes without guessing.
- Participants can identify where to get help if they cannot continue.
- Participants understand which steps require private information without exposing that information during research.

## Evidence and limitations
The worksheet is a starting point, not a substitute for screenshots or participant research. Capture at least five real screens/states from the live public workflow, annotate them, and replace prompts with verified observations. Do not invent findings or describe an untested assumption as a fact.

## Deliverables
- Figma pages: Evidence, Research, Flows, UI, Prototype
- Five or more annotated real screens/states
- Completed heuristic review
- One-page research question canvas
- Evidence worksheet with dated observations and design opportunities
