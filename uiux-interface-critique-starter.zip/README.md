# Interface Critique & Research Question Canvas

**Selected workflow:** DigiLocker account access and document retrieval  
**Official website:** https://www.digilocker.gov.in/

This repository contains a research canvas and an evidence worksheet starter for a UI/UX critique assignment.

## Important evidence note
The observations in the worksheet are **desk-review prompts based on publicly visible DigiLocker pages**, not usability-test findings. Verify the current live interface yourself, capture screenshots of the real pages/states, and update the worksheet with your own dated observations. Do not include personal information, OTPs, Aadhaar numbers, or account details in screenshots.

## Files
- `research-question-canvas.md` — one-page research canvas
- `research-evidence-worksheet.csv` — worksheet for observations, evidence, and design opportunities

## Suggested public workflow states to inspect
1. DigiLocker homepage
2. Register/sign-in entry point
3. Mobile-number entry screen
4. Alternative Aadhaar/VID entry screen (do not enter personal details)
5. Public help/FAQ or document-fetch guidance

Do not sign in or enter private information just to complete this critique. If a state requires authentication, label it as not inspected and use a publicly available help page or official guide instead.
